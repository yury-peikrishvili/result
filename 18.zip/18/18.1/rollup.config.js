export default {
    input: './index.js',
    output: {
      file: './build/bundle.js',
      format: 'cjs'
    }
  };